# lightsaber
A Lightsaber web app that is controlled using your phone
